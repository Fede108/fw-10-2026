#ifndef CONFIG_H
#define CONFIG_H

#define NB_MEM_ADDRESS  32
#define NB_MEM_DATA     32

#define ADDR_START_INST        0x00000000
#define ADDR_SIZE_INST         0x00020000
#define ADDR_START_DATA        0x00020000
#define ADDR_SIZE_DATA         0x00020000
#define ADDR_START_REG_FILE    0x00040000
#define ADDR_SIZE_REG_FILE     0x00020000

#define REG_FW_STATUS          (*(volatile unsigned int*)0x00040000)
#define REG_FW_REPORT          (*(volatile unsigned int*)0x00040004)

#define REG_AUX_0              (*(volatile unsigned int*)0x00040010)
#define REG_MCU_RESET          (*(volatile unsigned int*)0x00040014)
#define REG_DMA_SOURCE_ADDR    (*(volatile unsigned int*)0x00040018)
#define REG_DMA_DEST_ADDR      (*(volatile unsigned int*)0x0004001C)
#define REG_DMA_SIZE           (*(volatile unsigned int*)0x00040020)
#define REG_DMA_START          (*(volatile unsigned int*)0x00040024)
#define REG_DMA_DONE           (*(volatile unsigned int*)0x00040028)
#define REG_ADC_START          (*(volatile unsigned int*)0x0004002C)
#define REG_ADC_STATUS         (*(volatile unsigned int*)0x00040030)
#define REG_ADC_CLK_DIVIDER    (*(volatile unsigned int*)0x00040034)
#define REG_LED                (*(volatile unsigned int*)0x00040038)

#define REG_ARRAY_ADC_BUFF_BASE 0x00040100
#define REG_ARRAY_ADC_BUFF_SIZE 256
#define REG_ARRAY_ADC_BUFF ((volatile unsigned int*)REG_ARRAY_ADC_BUFF_BASE)


#define REG_UART0_START_TRANSMIT     (*(volatile unsigned int*)0x00042000)
#define REG_UART0_SIZE_TO_TRANSMIT   (*(volatile unsigned int*)0x00042008)
#define REG_UART0_TRANSMISION_DONE   (*(volatile unsigned int*)0x0004200C)
#define REG_ARRAY_UART0_BUFF_OUT_BASE 0x00042010
#define REG_ARRAY_UART0_BUFF_OUT_SIZE 256
#define REG_ARRAY_UART0_BUFF_OUT ((volatile unsigned int*)REG_ARRAY_UART0_BUFF_OUT_BASE)
#define REG_UART0_DATA_AVAILABLE     (*(volatile unsigned int*)0x00042800)
#define REG_UART0_DATA_FLUSH         (*(volatile unsigned int*)0x00042804)
#define REG_UART0_INDEX_IN           (*(volatile unsigned int*)0x00042808)
#define REG_ARRAY_UART0_BUFF_IN_BASE 0x0004280C
#define REG_ARRAY_UART0_BUFF_IN_SIZE 256
#define REG_ARRAY_UART0_BUFF_IN ((volatile unsigned int*)REG_ARRAY_UART0_BUFF_IN_BASE)

#define UART1_FIFO_DEPTH             16
#define UART1_SIM_BAUD_DIV           32
#define REG_UART1_BAUD_DIV           (*(volatile unsigned int*)0x00043000)
#define REG_UART1_CTRL               (*(volatile unsigned int*)0x00043004)
#define REG_UART1_TX_DATA            (*(volatile unsigned int*)0x00043008)
#define REG_UART1_STATUS             (*(volatile unsigned int*)0x0004300C)
#define REG_UART1_RX_DATA            (*(volatile unsigned int*)0x00043010)


#endif
